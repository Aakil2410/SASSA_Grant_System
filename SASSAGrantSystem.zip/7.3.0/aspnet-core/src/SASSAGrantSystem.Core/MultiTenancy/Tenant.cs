﻿using Abp.MultiTenancy;
using SASSAGrantSystem.Authorization.Users;

namespace SASSAGrantSystem.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
